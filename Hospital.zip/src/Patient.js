var Patient = function ( ID, lastName, firstName, feeOwing, doctorId  ) {
	this.id = ID;
	this.lastName = lastName;
	this.firstName = firstName;
	this.feeOwing = feeOwing;
	this.doctorId = doctorId;
};

Patient.prototype.getPaidStatus = function () {
    //return this.FeesOwing  = 0; ??
	if(this.feeOwing != 0){
		return true;
	};
	
};

// look
/*Patient.prototype.displayBillablePatients = function () {
    return this.doctorId + " - " + this.name;  
};*/

Patient.prototype.toString = function () {
    return this.lastName + " " + this.firstName;
};